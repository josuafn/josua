# josua
Sistem Informasi Geografis Sebaran Sekolah Menengah Pertama (SMP) di Kota Bandar Lampung
